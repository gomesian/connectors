#!/usr/bin/env python

import requests

"""
Description: Abuse IPDB API Integration.
Reference: https://docs.abuseipdb.com/#introduction
API Version - V2
Authentication Type - API Token based normal Authentication
"""


class AbuseIpdbConnector(object):
    """
        an object which make request on your behalf
    """
    def __init__(self, api_token, **kwargs):
        """
        description: init function
        :param api_token: api token
        :param kwargs:
        """
        api_version = "v2"
        url = "https://api.abuseipdb.com/api"
        self.base_url = "{0}/{1}".format(url, api_version)
        self.api_token = api_token

    def test_connection(self, **kwargs):
        """
        description: test connection
        :param kwargs:
        :return:
        """
        try:
            endpoint = self.base_url
            response = requests.request("GET", endpoint)
            if response.status_code < 500:
                return True
            else:
                return False
        except KeyError:
            return False

    def action_check_ip_address(self, ip_address, detailed_report=False,
                                get_report_since=30, **kwargs):
        """
        description: check ip address(v4/v6) reputation
        :param ip_address: ip address
        :param detailed_report: Want to include Detailed Report or not in response,
        Default value is False.
        :param get_report_since: determines how far back in time want to go to fetch
        reports. Default is '30' Days, min: 1 day, max: 365 days
        :param kwargs:
        :return:
        """
        endpoint = "check"
        query_string = {
            "ipAddress": ip_address,
            "verbose": detailed_report,
            "maxAgeInDays": get_report_since
        }
        response = self.request_handler("GET", endpoint,
                                        query_params=query_string)
        return response

    def action_check_cidr(self, network_subnet, get_report_since=30, **kwargs):
        """
        description: check subnet(v4/v6) reputation
        :param network_subnet: accept cidr in format like: "127.0.0.1/26"
        :param get_report_since: determines how far back in time want to go to fetch
        reports. Default: '30' Days, min: 1 day, max: 365 days
        :param kwargs:
        :return:
        """
        endpoint = "check-block"
        query_string = {
            "network": network_subnet,
            "maxAgeInDays": get_report_since
        }
        response = self.request_handler("GET", endpoint,
                                        query_params=query_string)
        return response

    def action_report_ip_address(self, ip_address, categories,
                                 description=None, **kwargs):
        """
        description: report ip address
        :param ip_address:
        :param categories: comma separated categories of IP to report.
        example: 3,6,10
                    3-Fraud Orders, 4-DDoS Attack,
                    5-FTP Brute-Force, 6-Ping of Death,
                    7-Phishing, 8-Fraud VoIP, 9-Open Proxy,
                    10-Web Spam, 11-Email Spam,
                    12-Blog Spam 13-VPN IP,
                    14-Port Scan, 15-Hacking
                    16-SQL Injection, 17-Spoofing,
                    18-Brute-Force, 19-Bad Web Bot,
                    20-Exploited Host, 21-Web App Attack
                    22-SSH, 23-IoT Targeted
        :param description: add some description about ip address
        :param kwargs:
        :return:
        """
        endpoint = "report"
        payload = {
            "ip": ip_address,
            "categories": categories,
            "comment": description
        }
        response = self.request_handler("POST", endpoint, payload=payload)
        return response

    def request_handler(self, method, endpoint, query_params=None,
                        payload=None, **kwargs):
        """
        description: function used for handling request and response
        :param method: http method
        :param endpoint: api request endpoint
        :param query_params: query params
        :param payload: payload
        :param kwargs:
        :return:
        """
        try:
            url = "{0}/{1}".format(self.base_url, endpoint)
            headers = {
                "Accept": "application/json",
                "Key": self.api_token
            }
            if method == "GET":
                response = requests.request("GET", url, params=query_params,
                                            headers=headers)
            elif method == "POST":
                response = requests.request("POST", url, json=payload,
                                            headers=headers)
            else:
                method_error = "Invalid Method {0} Requested!".format(method)
                return {"result": method_error, "execution_status": "ERROR"}

            if response.ok:
                response_json = response.json()
                return {"result": response_json, "execution_status": "SUCCESS"}
            elif response.status_code == 422 or response.status_code == 429:
                response_message = response.json()
                return {"result": response_message, "execution_status": "ERROR"}
            else:
                response_error = response.text
                return {"result": response_error, "execution_status": "ERROR"}

        except Exception as e:
            exception_error = str(e)
            return {"result": exception_error, "execution_status": "ERROR"}
